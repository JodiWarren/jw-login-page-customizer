=== JW Login Page Customizer ===
Contributors:      Jodi Warren
Tags:
Requires at least: 4.9
Tested up to:      4.9
Stable tag:        0.1.0

Style the login page from the WordPress customizer.

== Description ==

Easily style the login page from the WordPress customizer. Uses live previews to give the fastest and easiest experience.

You can also enter your own custom CSS, which will be injected live into the preview pane.

== Installation ==

= Manual Installation =

1. Upload the entire `/jw-login-page-customizer` directory to the `/wp-content/plugins/` directory.
2. Activate Jw Login Page Customizer through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1.0 =
* First release

== Upgrade Notice ==

= 0.1.0 =
First Release
